"""Central configuration loaded from environment variables / .env."""
import re
from functools import lru_cache

from pydantic import field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    app_name: str = "TenderBot AI"
    app_version: str = "1.0.0"
    database_url: str = "sqlite:///./tenderbot.db"
    public_base_url: str = "http://localhost:8000"

    @field_validator("public_base_url", mode="before")
    @classmethod
    def _clean_base_url(cls, value):
        """Accept a URL pasted as a markdown link ('[https://x](https://x)') or with spaces/quotes and keep a plain URL."""
        match = re.search(r"https?://[^\s\]\)\"'<>]+", str(value or ""))
        return match.group(0).rstrip("/") if match else value
    admin_api_key: str = ""

    openai_api_key: str = ""
    openai_model: str = "gpt-4o"

    twilio_account_sid: str = ""
    twilio_auth_token: str = ""
    twilio_whatsapp_from: str = "whatsapp:+14155238886"
    twilio_voice_from: str = ""
    twilio_approval_content_sid: str = ""
    validate_twilio_signature: bool = False

    twilio_verify_service_sid: str = ""
    android_package_name: str = ""
    android_sha256_fingerprints: str = ""
    require_auth: bool = True
    session_days: int = 30
    otp_sends_per_hour: int = 5
    fast2sms_api_key: str = ""
    otp_expiry_minutes: int = 5
    file_encryption_secret: str = ""
    max_upload_mb: int = 5
    chat_messages_per_hour: int = 40

    trial_days: int = 15
    basic_price: int = 999
    vip_price: int = 5000
    min_history_samples: int = 3
    expiry_alert_days: int = 30
    gst_rate_percent: float = 18.0
    gst_tds_rate_percent: float = 2.0
    gst_tds_threshold: float = 250000.0
    enable_scheduler: bool = True
    hunter_interval_hours: int = 6
    content_hour_ist: int = 8
    content_ai_background: bool = False
    content_video: bool = True
    google_tts_api_key: str = ""
    google_tts_voice: str = "mr-IN-Wavenet-A"
    openai_image_model: str = "gpt-image-1"
    facebook_page_id: str = ""
    facebook_page_token: str = ""
    instagram_business_id: str = ""
    meta_graph_version: str = "v23.0"
    telegram_bot_token: str = ""
    telegram_chat_id: str = ""
    admin_whatsapp: str = ""
    vault_check_interval_hours: int = 24

    submission_webhook_url: str = ""
    allowed_scrape_hosts: str = "mahatenders.gov.in,eprocure.gov.in,etenders.gov.in"

    @property
    def verify_configured(self) -> bool:
        """True when any OTP provider is set up: our own OTP via Fast2SMS, or Twilio Verify."""
        return bool(self.fast2sms_api_key or (self.twilio_account_sid and self.twilio_auth_token and self.twilio_verify_service_sid))

    @property
    def twilio_configured(self) -> bool:
        return bool(self.twilio_account_sid and self.twilio_auth_token)

    @property
    def scrape_hosts(self) -> list[str]:
        return [h.strip().lower() for h in self.allowed_scrape_hosts.split(",") if h.strip()]


@lru_cache
def get_settings() -> Settings:
    return Settings()
